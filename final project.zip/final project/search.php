<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Search Result</title>
</head>

<?php
session_start ();
$login="";

if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
		$username= $_SESSION["username"];
		$username = htmlspecialchars($username);
	}
}


if (isset($_POST['search'])){
   $search = $_POST['search'];
}

?>

<body onload="showAll()" class="movieListBody">

<form action="controller.php" method="post">
<ul class="homeul">
<li><a href="home.php"><code>Home</code></a></li>
<li><a href="rank.php?type=All"><code>Ranking List</code></a></li>
<li><a href="movieList.php?type=All"><code>All</code></a></li>
<li><a href="movieList.php?type=Thriller"><code>Thriller</code></a></li>
<li><a href="movieList.php?type=Comedy"><code>Comedy</code></a></li>
<li><a href="movieList.php?type=Action"><code>Action</code></a></li>
<li><a href="movieList.php?type=Fiction"><code>Fiction</code></a></li>
<li><a href="movieList.php?type=Romance"><code>Romance</code></a></li>
<li style="float:right" id="login"><a href="login.php"><code>Log In</code></a></li>
<li style="float:right" id="signUp"><a href="register.php"><code>Sign Up</code></a></li>
<?php
echo '<li style="float:right" id="username"><a><code>' . $username . '</code></a></li>'
?>
<li style="float:right" id="logout"><a href="controller.php?status=logout"><code id="logout">Log Out</code></a></li>
</ul>
</form>

<div id="allMovies"></div>

<script>
function showAll() {
	

	// login status
	
	<?php 
	if ($login == "valid"){
	?>
	    var login = document.getElementById("login");
     	var register = document.getElementById("signUp");
     	login.style.display = "none";
     	register.style.display = "none";
	<?php } else { ?>
		var logout = document.getElementById("logout");
		var username = document.getElementById("username");
		logout.style.display = "none";
     	username.style.display = "none";
	<?php }?>
	
	  var allMovies = document.getElementById("allMovies"); 
	  var moviesDisplay = '';
	  moviesDisplay += '<div id="header">';
	  moviesDisplay += '<div><code>';
	  moviesDisplay += 'Search Result';
	  moviesDisplay += '</code></div>';
	  moviesDisplay += '</div>';
	  
	  var ajax = new XMLHttpRequest();
	  ajax.open("GET", "controller.php?search=" + '<?php echo $search?>', true);
	  ajax.send(); 
	  ajax.onreadystatechange = function () {
		  if (ajax.readyState == 4 && ajax.status == 200) {
			  var array = JSON.parse(ajax.responseText);
			  console.log(array[0]);
			  for (var i=0; i<array.length; i++){
				 var temp =  array[i]['name'];
				 var movieName=array[i]['name'].toLowerCase().replace(/\s/g, '').replace(':','');
			     moviesDisplay += '<div class="oneMovie">';
			     moviesDisplay += '<a style="text-decoration:none;"href="movie.php?movieName=';
			     moviesDisplay += temp;
				 moviesDisplay += '">';
			     moviesDisplay += '<img class="listImg" src="./images/';
			     moviesDisplay += movieName;
			     moviesDisplay += '.jpg">';
			     moviesDisplay += '<div class="movieName"><code>' + array[i]['name'] + '</code></div>';
			     moviesDisplay += '</a>'
			     moviesDisplay += '</div>';
			  }
			 // alert(imagesDisplay);
			  allMovies.innerHTML = moviesDisplay;
		  }
	   }
	  }
</script>

</body>
</html>