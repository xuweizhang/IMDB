<?php
class DatabaseAdaptor {
	private $DB; // The instance variable used in every function
	// Connect to an existing data based named 'imdb_small'
	public function __construct() {
		$db = 'mysql:dbname=website; host=127.0.0.1; charset=utf8';
		$user = 'root';
		$password = ''; // an empty string
		try {
			$this->DB = new PDO ( $db, $user, $password );
			$this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		} catch ( PDOException $e ) {
			echo ('Error establishing Connection');
			exit ();
		}
	}
	
	//For database movie:
	public function  getAllMovie(){
		$stmt = $this->DB->prepare ("SELECT * FROM movies ORDER BY rating DESC;");
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	public function  getOneTypeMovie($movieType){
		$stmt = $this->DB->prepare ("SELECT * FROM movies WHERE type = '".$movieType."' ORDER BY rating DESC;");
		$stmt -> bindParam ('movieType',$movieType);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	public function searchMovie($movieName){
		$stmt = $this->DB->prepare ("SELECT * FROM movies WHERE name LIKE '%".$movieName."%';");
		$stmt -> bindParam ('movieName',$movieName);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	public function getOneMovie($movieName){
		$stmt = $this->DB->prepare ("SELECT movies.name, movies.director, movies.release_date,
 		movies.type, movies.rating, movies.description, movies.length, actors.actor_name, actors.role,
 		comment.username, comment.user_rating, comment.time, comment.comments from actors JOIN movies
 		ON movies.name = actors.movies      JOIN comment on comment.movie =actors.movies  where movies.name='".$movieName."';");
		$stmt -> bindParam ('movieName',$movieName);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	//insert movie data only available for administer user.***************
	public function  insertMovieData($name, $director, $release_date, $description, $type, $rating, $length){
		$stmt = $this->DB->prepare ("Insert into movies(name, director, release_date, description, type, rating, length) values 
                                  ('".$name."','".$director."', '".$release_date."', '".$description."', '".$type."', '".$rating."', 
									'".$length."');");
		$stmt->execute ();
	}
	//changeRating
	public function changeRating($id, $plus){
		if($plus >= 0)
			$stmt = $this->DB->prepare("UPDATE movies set rating=rating+".$plus." where id=".$quoteIdStoredAsHiddenParameter);
		else if($plus < 0)
			$stmt = $this->DB->prepare("UPDATE movies set rating=rating".$plus." where id=".$quoteIdStoredAsHiddenParameter);
		$stmt -> bindParam ('id',$id);
		$stmt -> bindParam ('plus',$plus);
		$stmt->execute ();
	}
	public function getMovieById($id){
		$stmt = $this->DB->prepare ("SELECT * FROM movies WHERE id =".$id);
		$stmt -> bindParam ('id',$id);
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
	
	
	//For database users:
	
	//verify whether the password match the username.
	public function verifyCredentials($userName, $psw){
		$Status = false;
		$stmt = $this->DB->prepare ("SELECT hash FROM users WHERE username='".$userName."'");
		$stmt -> bindParam ('userName',$id);
		$stmt -> bindParam ('id',$id);
		$stmt->execute ();
		$passwordArray = $stmt->fetchAll ( PDO::FETCH_ASSOC );
		if (count($passwordArray)>0){
			foreach ($passwordArray as $result){
				$hash_pwd=$result["hash"];
			}
			$loginStatus =  password_verify($psw, $hash_pwd);
		}
		return $loginStatus;
	}
	//check if the user is already exist.
	public function userCheck($username){
		$stmt = $this->DB->prepare ( "SELECT * FROM users WHERE username='".$username."'");
		$stmt -> bindParam ('username',$username);
		$stmt->execute ();
		$check = $stmt->fetchAll ( PDO::FETCH_ASSOC );
		$exist=!$check;
		return $exist;
	}
	//if it can register add user to database.
	public function addUser ($username, $password) {
		$stmt = $this->DB->prepare("INSERT INTO users (username, hash) values('".$username."','".$password."')");
		$stmt -> bindParam ('username',$username);
		$stmt -> bindParam ('password',$password);
		$stmt->execute();
	}
	
	//Get one movie's actors:
	
	//Insert one actors data into database:
	public function insertActorData($name, $gender, $movies, $date_of_birth, $role, $description, $location){
		$description= str_replace("'","&apos;",$description);
		$name= str_replace("'","&apos;",$name);
		$movies= str_replace("'","&apos;",$movies);
		$role= str_replace("'","&apos;",$role);
		$location= str_replace("'","&apos;",$location);
		
		$stmt=$this->DB->prepare("INSERT INTO actors(actor_name,gender,movies,date_of_birth,role,description,location) values
		('".$name."','".$gender."','".$movies."','".$date_of_birth."','".$role."','".$description."',  '".$location."');");
		$stmt -> bindParam ('Actorname',$name);
		$stmt -> bindParam ('gender',$gender);
		$stmt -> bindParam ('role',$role);
		$stmt -> bindParam ('movies',$movies);
		$stmt -> bindParam ('description',$description);
		$stmt -> bindParam ('location',$location);
		$stmt -> bindParam ('date_of_birth',$date_of_birth);
		$stmt->execute ();
	}
	
	// comment database:
	//insert data to comment:
	public function insertComment($username, $rating, $movie, $comments, $time){
		$comments= str_replace("'","&apos;",$comments);
		$stmt=$this->DB->prepare("INSERT INTO comment (username, user_rating, movie, comments, time) 
		values('".$username."','".$rating."','".$movie."','".$comments."','".$time."')");
		$stmt -> bindParam ('username',$username);
		$stmt -> bindParam ('user_rating',$rating);
		$stmt -> bindParam ('movie',$movie);
		$stmt -> bindParam ('comments',$comments);
		$stmt -> bindParam ('time',$time);
		$stmt->execute ();
	}
	public function getAllMoviesAndRoles() {
		// TODO 1: Complete this method
		$stmt = $this->DB->prepare ("select movies.name, movies.id, roles.role, actors.first_name, actors.last_name from roles
 join movies on roles.movie_id=movies.id join actors on actors.id=roles.actor_id;");
		
		
		$stmt->execute ();
		return $stmt->fetchAll ( PDO::FETCH_ASSOC );
	}
} // End class DatabaseAdaptor

$theDBA = new DatabaseAdaptor ();
//$arr=$theDBA -> searchMovie('A');
//$str = $array;
//for($i=1;$i<count($array);$i++){
	//if($array[$i]['name']!=$array[$i-1]['name']){
		//$str .= '<br>'.$array[$i]['name']."<br>";
	//}
	//$str .= '&nbsp&nbsp&nbsp&nbsp'.$array[$i]['first_name'].' '.$array[$i]['last_name'].'---'.$array[$i]['role'].'<br>';
//}
//print_r($arr[0]['name']);

?>

