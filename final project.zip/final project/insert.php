<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>

<?php 
session_start ();
if (isset($_SESSION['username'])) {
	$username= $_SESSION['username'];
}

if($username != "administer"){
	header("Location: ./home.php");
}
?>

<a href="home.php" class="returnHome"><code>-> Home</code></a>
<div class="insertBox">
<form action="controller.php" method="post" id="form1">
name:&nbsp;&nbsp;&nbsp;<input type="text" name="name"><br>
director:&nbsp;<input type="text" name="director"><br>
release_date:&nbsp;<input type="date" name="release_date"><br>
description:&nbsp;<textarea name="description" class="desInput"></textarea><br>
type:&nbsp;<input type="text" name="type"><br>
rating:&nbsp;<input type="text" name="rating"><br>
length:&nbsp;<input type="text" name="length"><br><br>
<input class="submitButton" type="submit" name="insertMovies" value="insert">
</form>
</div>

<br><br><br>

<div class="insertBox">
<form action="controller.php" method="post" id="form2">
actors name:&nbsp;<input type="text" name="name"><br>
gender:&nbsp;<input type="text" name="gender"><br>
date_of_birth:&nbsp;<input type="date" name="birth"><br>
role:&nbsp;<input type="text" name="role"><br>
description:&nbsp;<textarea name="description" class="desInput"></textarea><br>
movies:&nbsp;<input type="text" name="movies"><br>
location:&nbsp;<input type="text" name="location"><br><br><br>
<input class="submitButton" type="submit" name="insertActors" value="insert">
</form>
</div>

<div class="insertBox">
<form action="controller.php" method="post" id="form3">
username:&nbsp;<input type="text" name="username"><br>
movie:&nbsp;<input type="text" name="movie"><br>
comment:&nbsp;<textarea name="comment" class="desInput"></textarea><br>
rating:&nbsp;<input type="number" name="rating"><br>
time:&nbsp;<input type="date" name="time">
<br><br>
<input class="submitButton" type="submit" name="insertComments" value="insert">
</form>
</div>
</body>
</html>
