<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>home</title>
<link href="style.css" type="text/css" rel="stylesheet" />
</head>
<body onload="showPage()" class="home">

<?php
session_start (); 
$login="";

if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
	    $username= $_SESSION["username"];
     	$username = htmlspecialchars($username);
	}
}
?>

<form action="controller.php" method="post">
<ul class="homeul">
<!-- unfinished -->
<li><a href="d.php?type=Rank"><code>Ranking List</code></a></li>
<li><a href="movieList.php?type=New"><code>New</code></a></li>
<li><a href="movieList.php?type=Thriller"><code>Thriller</code></a></li>
<li><a href="movieList.php?type=Comedy"><code>Comedy</code></a></li>
<li><a href="movieList.php?type=Action"><code>Action</code></a></li>
<li><a href="movieList.php?type=Fiction"><code>Fiction</code></a></li>
<li><a href="movieList.php?type=Romance"><code>Romance</code></a></li>
<!-- unfinished -->
<li style="float:right" id="login"><a href="login.php"><code>Log In</code></a></li>
<li style="float:right" id="signUp"><a href="register.php"><code>Sign Up</code></a></li>
<?php
echo '<li style="float:right" id="username"><a><code>' . $username . '</code></a></li>'
?>
<li style="float:right" id="logout"><a href="controller.php?status=logout"><code id="logout">Log Out</code></a></li>
</ul>
</form>
 
 
<h1><code>Odd</code></h1>
<input type="text" name="search" class="search">
<button class="searchButton"><code>search</code></button>
<div id="time"></div>

<script>
function showPage(){

	// showTime
	time = new Date();
	year = time.getFullYear();
	month = time.getMonth() + 1;
	day = time.getDate();
	var str = '<code>' + month + "/" + day + "/" + year + "</code>";
	
	var time = document.getElementById("time");
	time.innerHTML = str;

	// login status
	
	<?php 
	if ($login == "valid"){
	?>
	    var login = document.getElementById("login");
     	var register = document.getElementById("signUp");
     	login.style.display = "none";
     	register.style.display = "none";
	<?php } else { ?>
		var logout = document.getElementById("logout");
		var username = document.getElementById("username");
		logout.style.display = "none";
     	username.style.display = "none";
	<?php }?>
}



</script>
</body>
</html>
