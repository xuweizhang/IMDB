<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>search result</title>
<link href="style.css" type="text/css" rel="stylesheet" />
</head>
<body>
<h2><i>search result</i></h2>
<br>
<div class="add">
<form action="controller.php" method="post">
	Comment:&nbsp;<textarea style="vertical-align:top" name="comment" cols="60" rows="5" 
	placeholder="Enter new comment" required></textarea>
    <br><br>
	Author:&nbsp;<input type="text" name="author" placeholder="Author" required>
    <br><br>
	<input class="submitButton" type="submit"  name="submit" value="Add Comment">
</form>	
</div>
</body>
</html>