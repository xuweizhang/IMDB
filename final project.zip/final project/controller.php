<?php
//controller.php
session_start();
require_once './DataBaseAdapter.php';
//search
if(isset( $_GET ['search'] ) ){
	$movieName=$_GET ['search'];
	$arr = $theDBA->searchMovie($movieName);
	echo json_encode($arr);
}
//changeRating
elseif (isset ( $_POST ['edit'] ) && isset ( $_POST ['id'] )) {
 $edit = $_POST ['edit'];
 $id = $_POST ['id'];
 if ($edit === 'plus') {
  $theDBA->changeRating ( $id, 1);
 }
 if ($edit === 'minus') {
  $theDBA->changeRating ( $id,-1 );
 }
 header ( "Location: ./movie.php?movieName=".getMovieById($id)[0]['name']);
}
//register.php
elseif (isset ( $_POST ['register'] )) {
 $username = $_POST ["username"];
 $password = $_POST ["password"];
 $existUser = $theDBA -> userCheck($username);
 if ($existUser == true){
  $hash_pwd = password_hash ( $password, PASSWORD_DEFAULT );
  $theDBA->addUser ( $username, $hash_pwd );
  header ( "Location: ./home.php");
 }else{
  $_SESSION["status"]='exist';
  header ( "Location: ./register.php" );
 }
}
//login.php
elseif (isset ($_POST['login'])){
 $username = $_POST ["username"];
 $password = $_POST ["password"];
 $verify = $theDBA -> verifyCredentials($username, $password);
 if ($verify == true){
  $_SESSION["loginStatus"]="valid";
  $_SESSION["username"]=$username;
  if($username == "administer")
  	header ( "Location: ./insert.php");
  else
  	header ( "Location: ./home.php");
 }else {	
	$_SESSION["loginStatus"]='invalid';
	header ( "Location: ./login.php" );
 }
}
//logout function
elseif (isset ($_GET['status'])){
	if($_GET['status'] == 'logout')
 		session_destroy();
 		header ( "Location: ./home.php");
}

//insert.php
//insert movie data:
elseif(isset ($_POST['insertMovies'])){
	$name=$_POST['name'];
	$director=$_POST['director'];
	$release_date=$_POST['release_date'];
	$description=$_POST['description'];
	$type=$_POST['type'];
	$length=$_POST['length'];
	$rating=$_POST['rating'];
	$theDBA->insertMovieData($name, $director, $release_date, $description, $type, $rating, $length);
	$_SESSION["username"]="administer";
	header ( "Location: ./insert.php");
}
//insert actors data:
elseif(isset ($_POST['insertActors'])){
	$name=$_POST['name'];
	$gender=$_POST['gender'];
	$date_of_birth=$_POST['birth'];
	$description=$_POST['description'];
	$role=$_POST['role'];
	$movies=$_POST['movies'];
	$location=$_POST['location'];
	$theDBA->insertActorData($name, $gender, $movies, $date_of_birth, $role, $description, $location);
	$_SESSION["username"]="administer";
	header ( "Location: ./insert.php");
}
//insert comment data:
elseif(isset ($_POST['insertComments'])){
	$username = $_POST['username'];
	$movie = $_POST['movie'];
	$rating = $_POST['rating'];
	$comment = $_POST['comment'];
	$time = $_POST['time'];
	$theDBA->insertComment($username, $rating, $movie, $comment, $time);
	$_SESSION["username"]="administer";
	header ( "Location: ./insert.php");
}
//movieList.php
elseif(isset($_GET['type'])&&$_GET['type'] == 'All'){
	$arr = $theDBA->getALlMovie();
	echo json_encode($arr);
}
elseif(isset($_GET['type'])){
	$type = $_GET['type'];
	$arr = $theDBA->getOneTypeMovie($type);
	echo json_encode($arr);
}
//movie.php
elseif(isset($_GET['movieName'])){
	$movieName = $_GET['movieName'];
	$arr = $theDBA->getOneMovie($movieName);
	echo json_encode($arr);
}
//Add comment
elseif(isset ($_POST['addComment'])&&isset($_GET['movie'])){
	$username = $_SESSION['username'];
	$movie = $_GET['movie'];
	$rating = $_POST['rating'];
	$comment = $_POST['comment'];
	
	date_default_timezone_set( "America/Phoenix" );  // If you want the correct date
	$time = date ( "Y-m-d" );
	
	$theDBA->insertComment($username, $rating, $movie, $comment, $time);
	header ( "Location: ./movie.php?movieName=".$movie);
}



	
?>