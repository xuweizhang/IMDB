<!DOCTYPE html>
<html>
<head>
<!-- Xuwei Zhang -->
<title>Movie Reviews</title>
<meta charset="utf-8" />
<link href="style.css" type="text/css" rel="stylesheet" />
</head>
<?php
session_start ();
$movieName = $_GET["movieName"];
//echo ($movieName);
$login="";
if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

//$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
	    $username= $_SESSION["username"];
     	$username = htmlspecialchars($username);
	}
}
?>

<body onload="show()">

<form action="controller.php" method="post">
<ul class="homeul">
<li><a href="home.php"><code>Home</code></a></li>
<li><a href="rank.php?type=All"><code>Ranking List</code></a></li>
<li><a href="movieList.php?type=All"><code>All</code></a></li>
<li><a href="movieList.php?type=Thriller"><code>Thriller</code></a></li>
<li><a href="movieList.php?type=Comedy"><code>Comedy</code></a></li>
<li><a href="movieList.php?type=Action"><code>Action</code></a></li>
<li><a href="movieList.php?type=Fiction"><code>Fiction</code></a></li>
<li><a href="movieList.php?type=Romance"><code>Romance</code></a></li>
<li style="float:right" id="login"><a href="login.php"><code>Log In</code></a></li>
<li style="float:right" id="signUp"><a href="register.php"><code>Sign Up</code></a></li>
<?php
echo '<li style="float:right" id="username"><a><code>' . $username . '</code></a></li>'
?>
<li style="float:right" id="logout"><a href="controller.php?status=logout"><code id="logout">Log Out</code></a></li>
</ul>
</form>

<div class="movieFrame" id="frame">
<div id="movieInfo"></div>
<p class="des"> · · · · · · · · · · · ·  · · · · · · · · · · · · · · · · · ·</p>

<h2 style="margin:2%;"><i>Add a comment</i></h2>
<br>
<?php if ($login == "valid"){
	echo '<div class="add">';
	echo '<form action="controller.php?movie='.$movieName.'" method="post">';
	echo 'Comment:&nbsp;<textarea style="vertical-align:top" name="comment" cols="60" rows="5"'; 
	echo 'placeholder="Enter new comment" required></textarea>';
	echo '<br><br>';
	echo 'Rating:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="rating"><br><br>';
	echo '<input class="submitButton" type="submit"  name="addComment" value="Add Comment">';
	echo '</form>';
	echo '</div>';
}
else{
	echo 'You should Log In First';
}
?>
</div>


<script>
function show(){
	<?php 
			if ($login == "valid"){
			?>
			    var login = document.getElementById("login");
		     	var register = document.getElementById("signUp");
		     	login.style.display = "none";
		     	register.style.display = "none";
			<?php } else { ?>
				var logout = document.getElementById("logout");
				var username = document.getElementById("username");
				logout.style.display = "none";
		     	username.style.display = "none";
			<?php }?>

			
	var str ="";
    var movieInfo=document.getElementById("movieInfo");
    var anObj = new XMLHttpRequest();
    //console.log(<?php $movieName?>);
    anObj.open("GET", "controller.php?movieName=" + '<?php echo $movieName?>' , true);
    //console.log("controller.php?movieName=" + '<?php echo $movieName?>')
    anObj.send();
    anObj.onreadystatechange = function() {
	   if (anObj.readyState == 4 && anObj.status == 200) {
		  var info = JSON.parse(anObj.responseText);
		  var temp =  info[0]['name'];
		  var movieName = info[0]['name'].toLowerCase().replace(/\s/g, '').replace(':','');
          str += '<div class="rateBox">';
          str += info[0]['rating'];
          str += '</div>';
          str += '<div class="movieName"><code>';
          str += temp;
          str += '</code></div>';
		  str += '<img class="movieImage" src="./images/';
		  str += movieName;
		  str += '.jpg" />';
          str += '<ul class="movieul">';
          str += '<li><a><code><b>Director: </b>';
          str += info[0]['director'];
          str += '</code></a></li>';
          str += '<li><a><code><b>Actors: </b>';
          for(var i=0;i<info.length-1;i++){
              if (info[i]['actor_name'] != info[i+1]['actor_name']){
                 str += info[i]['actor_name'];
                 str += '/';
              }
          }
          str += '</code></a></li>';
          str += '<li><a><code><b>Type: </b>';
          str += info[0]['type'];
          str += '</code></a></li>';
          str += '<li><a><code><b>Release Date: </b>';
          str += info[0]['release_date'];
          str += '</code></a></li>';
          str += '<li><a><code><b>Length: </b>';
          str += info[0]['length'];
          str += '</code></a></li>';
          str += '</ul>';
          str += '<br/>';     
          str += '<hr style="border-top: dotted 1px;color: black;" />';
          str += '<div class="des"><code>Description · · · · · · · · · · · · · · · </code></div>';
          str += '<p class="destxt">';
          str += '<code>';
          str += info[0]['description'];
          str += '</code>';
          str += '</p>';
          str += '<br/><br/><div class="des"><code>Review · · · · · · · · · · · · · · · · · ·</code></div>';
          var len = 0;
          if(info.length >= 5){
               len = 5;
          }else {
               len = info.length;
          }    
          for(var i=0;i<len;i++){
               str += '<div class="reviewbox">';
               str += '<code>';
               str += info[i]['user_rating'] + '/10' + '<br>';
               str += info[i]['username'] + '  ' + info[i]['time'] + '<br><br>';
               str += info[i]['comments'];
               str += '</code>';
               str += '</div>'
          }    
		  console.log(str);
          movieInfo.innerHTML = str; 
	   }
  }
}
</script>

</body>
</html>